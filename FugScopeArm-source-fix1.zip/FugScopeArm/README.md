# FugScope ARM — для Resolume 7 / Apple Silicon

Неофициальный перенос **fugScopeGL** Алекса Мэя на FFGL 2 и OpenGL Core.
Цель — источник звуковой волны для Resolume Arena/Avenue **7.11+** на Mac ARM.
Название в Resolume: **FugScope ARM**, вкладка **Sources**.

**Состояние: исходники и сборка подготовлены. Готового macOS `.bundle` в этом
архиве нет.** Проверены C++-код, FFGL API и реальная отрисовка в OpenGL 4.1
на Linux. По присланному пользователем логу на Mac прошли компиляция Apple
clang/CoreAudio, линковка и проверка Info.plist. Затем исходный скрипт остановился
на ошибке порядка аргументов `lipo`; она исправлена в архиве `source-fix1`.
Успешные проверка архитектуры, подпись, установка и запуск в Resolume пока
не подтверждены. Это кандидат для проверки на Mac.

## Как собрать и установить на Mac

1. Распакуйте весь архив на Mac с Apple Silicon, например в Downloads.
2. Если инструменты разработчика ещё не установлены, откройте Terminal и выполните
   `xcode-select --install`. Дождитесь установки Xcode Command Line Tools.
3. Закройте Resolume. Дважды щёлкните **Build and Install.command**.
   Если Finder не позволяет запустить скрипт, откройте Terminal, введите `bash `
   и перетащите этот `.command` в окно Terminal, затем нажмите Enter.
4. Скрипт соберёт ARM64-бинарник, проверит архитектуру, подпишет локальной
   ad-hoc подписью и скопирует bundle в
   `~/Documents/Resolume/Extra Effects/FugScopeArm.bundle`.
   Старая версия этого порта, если есть, переносится в соседнюю папку
   `~/Documents/Resolume/FugScope Backups/`.
5. Откройте Resolume → **Sources** → **FugScope ARM** → перетащите в пустой клип.
6. Включите **Test Signal**: должна появиться движущаяся белая волна.
   Затем выключите его для визуализации реального аудиовхода.

Homebrew, CMake и интернет для самой сборки не требуются: исходники зависимостей
включены. Нужны macOS 11+ и актуальные Xcode Command Line Tools с поддержкой ARM64.
Полная версия Xcode также подходит.

Для отдельной сборки из Terminal в папке этого проекта:

```bash
bash scripts/build-macos.sh arm64
bash scripts/install-macos.sh arm64
```

Для Universal (Apple Silicon + Intel):

```bash
bash scripts/build-macos.sh universal
bash scripts/install-macos.sh universal
```

### Исправление ошибки lipo в первом архиве

Если сборка уже дошла до `Info.plist: OK`, а затем остановилась с
`unknown architecture specification flag` и путём к бинарнику, повторная
компиляция не требуется. Закройте Resolume и выполните из папки проекта:

```bash
xcrun lipo "build/arm64/FugScopeArm.bundle/Contents/MacOS/FugScopeArm" -verify_arch arm64 &&
codesign --force --sign - "build/arm64/FugScopeArm.bundle" &&
bash scripts/install-macos.sh arm64
```

В `scripts/build-macos.sh` исправлен порядок: `lipo <бинарник> -verify_arch <архитектуры>`.
Для последующих сборок используйте исправленный архив `FugScopeArm-source-fix1.zip`.
Предупреждения `implicit-const-int-float-conversion` в PortAudio и FFGL SDK
не остановили показанную сборку; причина остановки — отдельная команда `lipo`.

Результат: `build/arm64/FugScopeArm.bundle` либо `build/universal/FugScopeArm.bundle`.
ARM64-сборка предназначена для Resolume, запущенного нативно. При запуске через
Rosetta используйте Universal. Resolume 7.0–7.10 не являются целевой конфигурацией.

## Аудио

Как оригинал, плагин берёт **первый канал системного аудиовхода macOS**, блоками
по 1024 отсчёта. Это не звук клипа и не автоматический захват общего звука Mac.
Вход выбирается в **Системные настройки → Звук → Вход**. Выберите микрофон,
аудиоинтерфейс или уже настроенное виртуальное loopback-устройство.
После изменения устройства выключите/включите Test Signal или заново откройте клип.

Разрешите доступ к микрофону **самому Resolume** в
**Конфиденциальность и безопасность → Микрофон**. Разрешение относится к хосту;
строка в Info.plist плагина не заменяет разрешения приложения.
Если изображение есть только при Test Signal: проверьте разрешение, системный
вход и уровень сигнала. Если разрешение ещё не запрошено, включите внешний
аудиовход в настройках Resolume, подтвердите системный запрос и перезапустите хост.

Используется 44100 Hz, как у оригинала; если устройство не поддерживает этот
формат, пробуется его стандартная частота. Аудио не записывается на диск и не
отправляется по сети. При ошибке входа источник остаётся доступным, рисует
тишину и пишет причину с префиксом `FugScope ARM audio:` в журнал хоста.

## Параметры

| Параметр | Значения / назначение |
|---|---|
| Config | Line, Points, Fill, Points Mirror, Line Mirror, Fill Bottom, Fill Top |
| Arrange | Normal, Mirror1, Mirror2 — логика оригинала |
| Scale | Усиление 0–10; по умолчанию 1 |
| Width | Толщина линий/точек 1–50 px; по умолчанию 1 |
| Test Signal | Встроенная тестовая волна; выключен по умолчанию |

Scale и Width передаются через FFGL как нормализованные 0–1, а их отображение
показывает реальные величины. Width не меняет заполненные режимы. Цвет белый,
фон прозрачный; окраску и последующую обработку можно добавить эффектами Resolume.

## Отличия и границы совместимости

- Сохранены семь режимов, три Arrange, четыре исходных параметра и алгоритм
  signed-max выборки аудио. Добавлен только Test Signal.
- Отрисовка переведена на GLSL 4.10, VAO/VBO и треугольники. Исправлены толстые
  линии и заливки; побитовая идентичность старому OpenGL не заявляется.
- Исправлены гонка аудиобуфера, null input, переменный размер аудиоблока и нечётная
  ширина кадра. Несколько экземпляров используют общий счётчик PortAudio runtime.
- ID `FSAR` отличается от оригинального `BF24`. Старые композиции и пресеты
  автоматически не подменяются; добавьте новый источник вручную.
- Подпись локальная (ad-hoc), без Developer ID и notarization.
- Смена/отключение аудиоустройства во время работы требует перезапуска захвата.
- Реальные CoreAudio latency, совместимость устройств и FPS на Apple GPU ещё
  требуют проверки.

## Проверки и продолжение разработки

`bash scripts/test-core.sh` запускает тесты resampling, геометрии, SPSC-очереди
и жизненного цикла захвата с моделью аудиодрайвера под ASan/UBSan.
`scripts/test-linux-gl.sh` собирает тестовую Linux-библиотеку и запускает
настоящий OpenGL/FFGL host; она не предназначена для установки в Resolume.
Подробные результаты и оставшиеся проверки: [VALIDATION.md](VALIDATION.md).
GitHub Actions workflow в `.github/workflows/macos.yml` подготовлен для сборки
Universal на macOS runner, но здесь не запускался и никуда не публиковался.

**Следующий шаг для агента с доступом к Mac:** выполнить `build-macos.sh arm64`,
либо завершить уже выполненную сборку командами выше, установить bundle, пройти сценарии из
VALIDATION.md на Resolume 7.11+, обновить этот README и приложить проверенный
bundle вместе с соответствующими исходниками.

## Источники

- [Исходники bigfug](https://github.com/bigfug/Freeframe) и [код fugScopeGL](https://github.com/bigfug/Freeframe/tree/master/FreeFrame/ffgl/fugScopeGL).
- [Официальный SDK Resolume FFGL](https://github.com/resolume/ffgl).
- [Нативная поддержка Apple Silicon с Resolume 7.11](https://resolume.com/blog/21445).
- [Каталоги FFGL в Resolume](https://resolume.com/support/preferences).

Авторство, изменения и лицензии: [NOTICE.md](NOTICE.md). Этот порт и исходники
оригинала — GPL-3.0. Лицензии SDK и PortAudio сохранены отдельно.
