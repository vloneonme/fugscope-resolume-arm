/*

The MIT License

Copyright (c) 2007 Alex May - www.bigfug.com

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

*/

#pragma once

#include "StreamDecoder.h"
#include <stdio.h>

#include <boost/format.hpp>

class StreamDecoderTCP : public StreamDecoder
{
protected:
	SOCKET					 mServerSocket;
	SOCKET					 mClientSocket;
	struct sockaddr_in		 mClientAddr;
	socklen_t				 mClientAddrLength;
	FrameData				 mHdr1, mHdr2;
	std::vector<char>		 mPkt1, mPkt2;
	size_t					 mDat1, mDat2;
	int						 mReadBuff, mWriteBuff;
	bool					 mReaderLocked;

#ifdef WIN32
	int							 mWSAresult;
#endif

public:
	StreamDecoderTCP( const fugVideoInfo &pDstInfo );
	virtual ~StreamDecoderTCP( void );

	virtual bool hasNewFrame( void );

	virtual bool waitForNewFrame( uint32_t pTimeout );

protected:
	virtual uint8_t *lockFrame( uint32_t pTimeout, size_t &pSize );

	virtual void freeFrame( void );

	bool openPort( void );

	void closePort( void );

	void read( uint32_t pWait );
};
